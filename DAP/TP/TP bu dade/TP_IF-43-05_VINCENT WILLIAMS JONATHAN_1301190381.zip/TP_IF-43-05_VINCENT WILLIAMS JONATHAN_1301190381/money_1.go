package main

import "fmt"

func main() {
  var uang int

  fmt.Print("Masukkan uang: ")
  fmt.Scan(&uang)

for uang % 25 != 0 {
  fmt.Println(uang," Tidak valid")
  fmt.Print("Masukkan uang: ")
  fmt.Scan(&uang)
}
  fmt.Println(uang," Valid")
}
